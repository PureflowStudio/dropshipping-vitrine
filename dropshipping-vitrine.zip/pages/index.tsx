import { useState } from "react";

const produits = [
  {
    nom: "Chapeau de paille été",
    prixAchat: 4,
    prixVente: 14.99,
    marge: 10.99,
    delai: "3 à 5 jours",
    saison: "été",
    concurrents: ["Amazon", "Cdiscount"],
    tendances: ["mode plage", "vacances"],
    images: ["/images/chapeau.jpg"]
  },
  {
    nom: "Serviette de plage XXL",
    prixAchat: 7,
    prixVente: 19.99,
    marge: 12.99,
    delai: "5 jours",
    saison: "été",
    concurrents: ["Shein", "AliExpress"],
    tendances: ["été", "mer"],
    images: ["/images/serviette.jpg"]
  }
];

export default function Home() {
  const [saisonFiltre, setSaisonFiltre] = useState("été");

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Produits tendance - Saison : {saisonFiltre}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {produits
          .filter(p => p.saison === saisonFiltre)
          .map((p, i) => (
            <div key={i} className="border p-4 rounded shadow">
              <img src={p.images[0]} alt={p.nom} className="w-full h-48 object-cover rounded" />
              <h2 className="text-xl font-semibold mt-2">{p.nom}</h2>
              <p>Prix d’achat : {p.prixAchat} €</p>
              <p>Prix de vente conseillé : {p.prixVente} €</p>
              <p>Marge estimée : {p.marge.toFixed(2)} €</p>
              <p>Délai livraison : {p.delai}</p>
              <p className="text-sm text-gray-600">Concurrents : {p.concurrents.join(", ")}</p>
              <p className="text-sm text-blue-600">Tendances : {p.tendances.join(", ")}</p>
            </div>
        ))}
      </div>
    </div>
  );
}